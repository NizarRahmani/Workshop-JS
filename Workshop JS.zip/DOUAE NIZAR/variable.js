var num1 = document.querySelector("#number1");
 var num2 = document.querySelector("#number2");
   
function switchBtn(){  
  
        let curValue1 = number1.value; 
          let curValue2 = number2.value; 
            num1.value = curValue2; 
              num2.value = curValue1; 
            }
